#!/usr/bin/env bash
# Builds two APKs into dist/:
#   SubtitleReader.apk    - updates the "Subtitle Reader" app (keeps its episodes and words)
#   SubtitleReader-2.apk  - a separate app, "Subtitle Reader 2", that installs next to the first
# Both are signed with ci/debug.keystore, so each one updates itself over later builds.
set -euo pipefail
RUN="${RUN_NUMBER:-1}"
GRADLE="${GRADLE:-./gradlew}"

npm ci --no-audit --no-fund
npx cap add android
cp -r android-res/* android/app/src/main/res/
sed -i "s/versionCode 1$/versionCode ${RUN}/" android/app/build.gradle
sed -i "s/versionName \"1.0\"/versionName \"1.${RUN}\"/" android/app/build.gradle
npx cap sync android
mkdir -p ~/.android && cp ci/debug.keystore ~/.android/debug.keystore
rm -rf dist && mkdir -p dist

cd android
chmod +x gradlew
$GRADLE assembleDebug --no-daemon
cp app/build/outputs/apk/debug/app-debug.apk ../dist/SubtitleReader.apk

# the second app: its own id (so Android keeps both), name and teal icon
grep -q 'applicationId "kz.subtitlereader.app"' app/build.gradle
sed -i 's/applicationId "kz.subtitlereader.app"/applicationId "kz.subtitlereader.app2"/' app/build.gradle
sed -i 's|<string name="app_name">Subtitle Reader</string>|<string name="app_name">Subtitle Reader 2</string>|' app/src/main/res/values/strings.xml
sed -i 's|<string name="title_activity_main">Subtitle Reader</string>|<string name="title_activity_main">Subtitle Reader 2</string>|' app/src/main/res/values/strings.xml
cp -r ../android-res-2/* app/src/main/res/
rm -rf app/build/outputs/apk
$GRADLE assembleDebug --no-daemon
cp app/build/outputs/apk/debug/app-debug.apk ../dist/SubtitleReader-2.apk
ls -l ../dist
