#!/usr/bin/env bash
# Builds two APKs into dist/:
#   SubtitleReader.apk    - updates the "Subtitle Reader" app (keeps its episodes and words)
#   SubtitleReader-2.apk  - a separate app, "Subtitle Reader 2", that installs next to the first
# Both are signed with ci/debug.keystore, so each one updates itself over later builds.
# The video sync part (native/*.java) is added too; if it does not compile, the APKs are
# built without it and the app shows the compiler's message in Aa -> Video.
set -euo pipefail
RUN="${RUN_NUMBER:-1}"
GRADLE="${GRADLE:-./gradlew}"

npm ci --no-audit --no-fund
npx cap add android
cp -r android-res/* android/app/src/main/res/
sed -i "s/versionCode 1$/versionCode ${RUN}/" android/app/build.gradle
sed -i "s/versionName \"1.0\"/versionName \"1.${RUN}\"/" android/app/build.gradle
npx cap sync android
mkdir -p ~/.android && cp ci/debug.keystore ~/.android/debug.keystore
rm -rf dist && mkdir -p dist

cd android
chmod +x gradlew
J=app/src/main/java/kz/subtitlereader/app
M=app/src/main/AndroidManifest.xml
NOTE=app/src/main/assets/public/build-note.txt
cp "$J/MainActivity.java" /tmp/MainActivity.java.orig
cp "$M" /tmp/AndroidManifest.xml.orig

add_sync() {
  cp ../native/MediaSyncPlugin.java ../native/MediaListener.java ../native/MainActivity.java "$J/"
  python3 - "$M" <<'PY'
import sys
p = sys.argv[1]; s = open(p).read()
svc = '''        <service
            android:name=".MediaListener"
            android:label="@string/app_name"
            android:exported="true"
            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService" />
            </intent-filter>
        </service>
'''
if 'MediaListener' not in s:
    assert '    </application>' in s
    s = s.replace('    </application>', svc + '    </application>', 1)
open(p, 'w').write(s)
PY
}
remove_sync() {
  rm -f "$J/MediaSyncPlugin.java" "$J/MediaListener.java"
  cp /tmp/MainActivity.java.orig "$J/MainActivity.java"
  cp /tmp/AndroidManifest.xml.orig "$M"
}
build_apk() { rm -rf app/build/outputs/apk; $GRADLE assembleDebug --no-daemon; }

add_sync
if ! build_apk 2>&1 | tee /tmp/gradle-sync.log; then
  echo "::warning::Video sync did not compile; building without it"
  remove_sync
  { echo "Video sync is not in this build (build ${RUN}). Send this to Claude:"; grep -E "error:|\.java:[0-9]+|FAILURE|What went wrong" /tmp/gradle-sync.log | head -12 || true; } > "$NOTE"
  build_apk
fi
cp app/build/outputs/apk/debug/app-debug.apk ../dist/SubtitleReader.apk

# the second app: its own id (so Android keeps both), name and teal icon
grep -q 'applicationId "kz.subtitlereader.app"' app/build.gradle
sed -i 's/applicationId "kz.subtitlereader.app"/applicationId "kz.subtitlereader.app2"/' app/build.gradle
sed -i 's|<string name="app_name">Subtitle Reader</string>|<string name="app_name">Subtitle Reader 2</string>|' app/src/main/res/values/strings.xml
sed -i 's|<string name="title_activity_main">Subtitle Reader</string>|<string name="title_activity_main">Subtitle Reader 2</string>|' app/src/main/res/values/strings.xml
cp -r ../android-res-2/* app/src/main/res/
build_apk
cp app/build/outputs/apk/debug/app-debug.apk ../dist/SubtitleReader-2.apk
ls -l ../dist
