package kz.subtitlereader.app;

import android.service.notification.NotificationListenerService;

/**
 * Exists only so Android can grant "notification access", which is what lets
 * the app see the video app's playback (position and play/pause). It reads nothing.
 */
public class MediaListener extends NotificationListenerService {
}
